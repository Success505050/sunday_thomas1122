const allowedOrigins = [
    'http://localhost:3000',
    'http://localhost:3500/',
    'https://food-delivery-1.onrender.com',
    'https://foodietesty.netlify.app',
]

module.exports = allowedOrigins